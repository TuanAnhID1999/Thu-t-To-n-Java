import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



@SuppressWarnings("unchecked")

public class OrderedArraySimpleTable <Key extends Comparable<Key>, Value> implements OrderedSimpleTable<Key, Value> {

	private Key[]  keys;
	private Value[] values;
	int n = 0, default_size = 100;


	// Chú ý hoàn thiện hàm dựng, khởi tạo 2 mảng keys và values
	public  OrderedArraySimpleTable() {
		// keys extend Comprable
		keys = (Key[]) new Comparable[default_size];
		values = (Value[]) new Object[default_size];
		n = 0 ;
	}

	@Override
	//Phương thức thực hiện thêm 1 phần tử vào bảng tra cứu, phần tử mới được thêm vào sao
	// cho mảng keys luôn được sắp tăng dần
	public void put(Key key, Value value) {
		// TODO Auto-generated method stub
		int id = binarySearch(key); //tim key xem co ko
		if(id>-1) { //tim duoc => gan value cu bang value moi
			values[id]= value;
		}
		else {

			if(n>=keys.length){
				keys = Arrays.copyOf(keys, keys.length*3/2); //mo rong mang
				values = Arrays.copyOf(values, values.length*3/2); //mo rong mang
			}

			int r = rank(key);
			for(int i = n ;  i> r ; i--) {
				keys[i] = keys[i-1];
				values[i] = values[i-1];
				//vd : 1 2 4 6 7 10, chen "5" vao thi tu 6 7 10 lui 1 don vi 
			}

			keys[r] = key;
			values[r] = value;

			n++;
		}

	}



	//Phương thức thực hiện tìm kiếm khóa key trên mảng keys bằng thuật toán tìm kiếm nhị phân
	// kết quả trả về là chỉ số (index) của phần tử key trong mảng key
	// nếu không tìm thấy key trong mảng keys, trả lại -1
	public int binarySearch(Key key)
	{
		// u la phan tu bien ben trai bat dau tu o , v la phan tu ben phai
		int u =  0 , v = n - 1 ;
		while(u<=v){
			//m la middle
			int m = (u+v)/2 ;
			if(key.compareTo(keys[m])==0) {
				return m;
			}
			else {
				if(key.compareTo(keys[m]) > 0 ) {
					u = m+1 ;
				}
				else {
					v = m-1;
				}
			}
		}


		return -1;
	}


	// Phương thức get, lấy ra giá trị value tương ứng với key
	// Phương thức này gọi tới phương thức binarySearch(Key key)
	@Override
	public Value get(Key key) {
		// TODO Auto-generated method stub
		int id = binarySearch(key);
		if(id > -1) {
			return values[id];
		}
		return null;
	}


	@Override
	// xóa phần tử ra khỏi bảng tra cứu, dồn lại mảng sau khi xóa
	public void delete(Key key) {
		// TODO Auto-generated method stub
		int id = binarySearch(key);
		if(id > -1) {
			n--;
			for(int i = id ; i < n ; i++) { //vd 1 2 4 5 7 xoa "4" thi don 5 7 lai -> 1 2 5 7
				keys[i] = keys[i+1];
				values[i] = values[i+1];
			}
		}
	}

	@Override
	public boolean contains(Key key) {
		// TODO Auto-generated method stub
		return binarySearch(key)>-1;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return n==0;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return n;
	}

	@Override
	public Iterable<Key> keys() {
		// TODO Auto-generated method stub
		List<Key> lk = new ArrayList<Key>();
		for( int i = 0 ; i < n ; i ++)
			lk.add(keys[i]);
		return lk;
	}

	@Override
	public Key min() {
		// TODO Auto-generated method stub
		if(!isEmpty()) {
			return keys[0];
		}
		return null;
	}

	@Override
	public Key max() {
		// TODO Auto-generated method stub
		if(!isEmpty()){
			return keys[n-1];
		}
		return null;
	}

	@Override
	public Key floor(Key key) {
		// TODO Auto-generated method stub
		int id = -1;
		for(int i = 0 ; i < n ; i++) {
			if(key.compareTo(keys[i]) >=0) { 
				id = i;
			}
			else
				break;
			
		}
		
		if(id > -1)
			return keys[id]; // tim thay
		return null;
	}

	@Override
	public Key ceiling(Key key) {
		// TODO Auto-generated method stub
		int id = -1;
		for(int i = n-1 ; i>=0 ; i--) {
			if(key.compareTo(keys[i])<=0) {
				id = i;
			}
			else
				break;
		}
		if(id > -1)
			return keys[id];
		return null;
	}

	@Override
	public int rank(Key key) {
		// TODO Auto-generated method stub
		int count = 0 ;
		for ( int i = 0 ; i < n ; i++) {
			if ( key.compareTo(keys[i])>0)
				count++;
			else break;
		}
		return count;
	}

	@Override
	public Key select(int k) {
		// TODO Auto-generated method stub
		for ( int i = 0 ; i< n ; i++) {
			if(rank(keys[i]) == k) 
				return keys[i];
		}
		return null;
	}

	@Override
	public void deleteMin() {
		// TODO Auto-generated method stub
		if(!isEmpty()) {
			n--;
			for(int i = 0 ; i < n ; i++) {
				keys[i] = keys[i+1];
				values[i]= values[i+1];
			}
		}

	}

	@Override
	public void deleteMax() {
		// TODO Auto-generated method stub
		if(!isEmpty()) {
			n--;
		}
	}

	@Override
	public int size(Key u, Key v) {
		// TODO Auto-generated method stub
		// Cach 1 la lay rank cua thang lon - rank thang be - 1
		// vd 1 2 4 6 8 10 ; v = 10 ; u = 6 rank 10 la 5 ; rank 6 la 3 => so phan tu 6<x<10 la 1 phan tu la 8
		//Cach 2 : Dem thong thuong
		int count = 0;
		for(int i = 0 ; i < n ; i ++) {
			if(keys[i].compareTo(u)>0 && keys[i].compareTo(v) < 0) {
				count++;
			}
		}
		return count;
	}

	@Override
	public Iterable<Key> keys(Key u, Key v) {
		List<Key> lk = new ArrayList<Key>();
		for(int i = 0 ; i < n ; i ++) {
			if(keys[i].compareTo(u)>0 && keys[i].compareTo(v) < 0) {
				lk.add(keys[i]);
			}
		}// TODO Auto-generated method stub
		return lk;
	}

}