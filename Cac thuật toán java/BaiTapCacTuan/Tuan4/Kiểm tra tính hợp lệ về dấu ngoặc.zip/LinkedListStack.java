import java.util.Iterator;

import javax.xml.soap.Node;


public class LinkedListStack<T> implements StackInterface<T> {

	class Node{
		T element;
		Node next;
	}
	Node stack = null;
	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void push(T element) {
		// TODO Auto-generated method stub
		Node p = new Node();
		p.element = element;
		p.next = stack;
		stack = p;
		
	}

	

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return stack == null;
	}

	@Override
	public T pop() {
		// TODO Auto-generated method stub
		Node p = stack;
		if(stack != null){
			stack = stack.next;
			return p.element;
		}
		return null;
	}
	
	class StackIterator implements Iterator<T> {

		private Node currentNode = stack;
		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return currentNode != null;
		}

		@Override
		public T next() {
			// TODO Auto-generated method stub
			return null;
		}

	}

}


