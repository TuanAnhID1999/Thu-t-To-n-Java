import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Insert {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int x = scan.nextInt();
		int[] A = new int[n];
		LinkedList<Integer> array = new LinkedList<Integer>();
		for (int i = 0; i < n; i++) {
			array.add(scan.nextInt());
		}
		array.add(x);
		Collections.sort(array);
		for (Integer element : array) {
			System.out.print(element + " ");
		}
	}

}

