
public class Robot {
	public  int countPath(int M, int N, int t)
	{	
			int countleft = count(t,M);
			int  countright = count(N-t , M);
			return countleft + countright ;
	
	}
	public  int count(int nCol , int nRow ){
		int rez = 0;
		if(nCol == 1 && nRow ==1){
			return 1;
		}
		if(nCol > 1){
			rez += count(nCol - 1,nRow);
		}
		if(nRow > 1){
			rez += count(nCol,nRow -1);
		}
		return rez;
		
	}
//	public static void main(String [] args){
//		int m , n,t;
//		m=4;
//		n=4;
//		n=2;
//		Robot robot = new Robot();
//		System.out.println(robot.countPath(4,4,2));
//	}
}
