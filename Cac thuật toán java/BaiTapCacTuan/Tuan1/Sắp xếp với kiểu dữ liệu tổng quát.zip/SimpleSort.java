import java.util.Comparator;
@SuppressWarnings("unchecked")
public class SimpleSort {
	
	// Phương thức sắp xếp cho dữ liệu có giao diện Comparable (có thể so sánh được)
	public static void sort(Comparable[] a)
	{

		for(int i =a.length-1; i > 0; i-- ){
			for (int j = 0; j < i; j++) {
				if (a[j].compareTo(a[j+1]) > 0) {
					Comparable<Comparable> t = a[j];
					a[j]=a[j+1];
					a[j+1] = t;
				}
			}
		}
	}
	
	// Phương thức sắp xếp cho dữ liệu tổng quát T, thông qua bộ so sánh compare
	public  static <T> void sort(T[] a, Comparator<T> compare){
		for(int i =a.length-1; i > 0; i-- ){
			for (int j = 0; j < i; j++) {
				if (compare.compare(a[j], a[j+1]) >0) {
					T t = a[j];
					a[j]=a[j+1];
					a[j+1] = t;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		
		Integer[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		
		Comparator<Integer> comp = new Comparator<Integer>() {			
			@Override
			public int compare(Integer o1, Integer o2) {
				// TODO Auto-generated method stub
				if (o1%2 == o2%2)
					return o1 - o2;
				else
					return o1%2 - o2%2;
			}
		};
		
		sort(a, comp);
		for(int i = 0 ; i < a.length ; i++)
			System.out.print(a[i]);
	}

}