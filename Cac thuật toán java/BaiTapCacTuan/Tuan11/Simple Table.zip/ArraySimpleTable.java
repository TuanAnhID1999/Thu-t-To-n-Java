import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;



@SuppressWarnings({"unchecked", "deprecation"})
public class ArraySimpleTable<Key extends Comparable<Key>, Value> extends AbstractSimpleTable<Key, Value>{

	private Key [] keys;
	private Value [] values;
	private int n = 0;
    public ArraySimpleTable(){
        keys = (Key[]) new Comparable[100];
        values = (Value[]) new Object[100];
    }
	@Override
	public void put(Key key, Value value) {
		// TODO Auto-generated method stub
		boolean contain = false;
		for (int i = 0; i < n; i++) {
			if(this.keys[i].compareTo(key) == 0){
				this.values[i] = value;
				contain = true;
				break;
			}
		}
		if(contain == false){
			if(n >= this.keys.length){
				extentArray();
			}
			this.keys[n] = key;
			this.values[n] = value;
			n++;
		}
	}

	@Override
	public Value get(Key key) {
		// TODO Auto-generated method stub
		for (int i = 0; i < n; i++) {
			if(keys[i].equals(key)){
				return values[i];
			}
		}
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return size() == 0;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		int count = 0;
		for (int i = 0; i < n; i++) {
			if(values[i] != null){
				count++;
			}
		}
		return count;
	}

	@Override
	public Iterable<Key> keys() {
		// TODO Auto-generated method stub
		ArrayList<Key> list = new ArrayList<Key>();
		for (int i = 0; i < n; i++) {
			if(values[i]!=null)
				list.add(keys[i]);
		}
		
		return list;
	}
	public void extentArray(){
		keys = Arrays.copyOf(keys,keys.length*3/2);
		values = Arrays.copyOf(values, values.length*3/2);
	}



}