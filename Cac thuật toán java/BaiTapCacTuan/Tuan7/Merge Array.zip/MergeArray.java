public class MergeArray {

	public int[] mergeArray(int[] a, int[] b) {
		int[] c = new int[a.length + b.length];
		int i = 0;
		int j = 0;
		int k = 0;
		while (k < c.length) {
			if (i < a.length && j < b.length) {
				if (a[i] <= b[j]) {
					c[k] = a[i];
					i++;
				} else {
					c[k] = b[j];
					j++;
				}
			} else {
				if (a.length > b.length) {
					c[k] = a[i];
					i++;
				} else {
					c[k] = b[j];
					j++;
				}
			}
			k++;
		}
		return c;
	}

	// 1 2 3 4 5
	// 2 3 5 6 7,8,9
	// 1 2 2 3 3 4 5 5 6 7
	public static void main(String[] args) {
		int[] a = { 1, 2, 5,7,9};
		int[] b = { 0,2,4,6,8,10,12};
		new MergeArray().mergeArray(a, b);

	}

}

