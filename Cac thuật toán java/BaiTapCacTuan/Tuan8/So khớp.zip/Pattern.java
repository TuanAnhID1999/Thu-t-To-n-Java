public class Pattern{
    
    
    
    public int match(int[] a, int[] b)
    {
    	int vt = -1;
    	for (int i = 0; i <= b.length-a.length; i++) {
    		int j;
    		for(j = 0; j < a.length; j++){
    			if(b[i+j] != a[j]){
    				break;
    			}
    		}
    		if(j == a.length){
    			vt = i;
    			break;
    		}
			
		}
    	
    	return vt;
    }
//     public static void main(String[] args) {
// 		int[] a = {1,2,3,4};
// 		int [] b = {2,2,1,2,3,4,4,3,4};
// 		Pattern p = new Pattern();
// 		System.out.println(p.match(a, b));
// 	}
    
}