import java.util.ArrayList;

public class RLE {
	/**
	 * Computes the length of the compression array.
	 * 
	 * @param t
	 *            a binary array
	 * @return an integer.
	 */
	public static int length(int[] t) {
		return compress(t).length;
	}

	/**
	 * Compresses an array in RLE format and return the result.
	 * 
	 * @param t
	 * @return compressed array.
	 */
	public static int[] compress(int[] t) {
		int count = 0;
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < t.length; i++) {
			for (int j = i; j < t.length; j++) {
				if (t[i] == t[j]) {
					count++;
				}else{
					break;
				}
			}
			list.add(t[i]);
			list.add(count);
			i = i + count - 1;
			count = 0;
		}
		t = new int[list.size()];
		int index = 0;
		for (Integer element : list) {
			t[index++] = element;
		}
		return t;
	}

	/**
	 * Computes the length of the decompressed array.
	 * 
	 * @param t
	 * @return an integer.
	 */
	public static int lengthInverse(int[] t) {
		// TODO: Your code here
		return decompress(t).length;
	}

	/**
	 * Decompresses the array.
	 * 
	 * @param t
	 * @return an array
	 */
	public static int[] decompress(int[] t) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < t.length-1; i+=2) {
			for (int j = 0; j < t[i+1]; j++) {
				list.add(t[i]);
			}
		}
		t = new int[list.size()];
		int index = 0;
		for (Integer element : list) {
			t[index++] = element;
		}
		return t;
	}

	public static void main(String[] args) {
	}
}

