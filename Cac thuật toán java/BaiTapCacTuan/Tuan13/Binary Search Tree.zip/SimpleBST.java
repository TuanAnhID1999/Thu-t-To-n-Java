import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Arrays;

@SuppressWarnings("unchecked")
public class SimpleBST<Key extends Comparable<Key>> implements
		SimpleBTreeInterface<Key> {

	class Node {
		Key data;
		Node left, right;

		public Node(Key key) {
			this.data = key;
		}
	}

	private Node root = null;
	int n = 0;

	public void insert(Key k) {
		if (root == null) {
			root = new Node(k);
		} else {
			Node p = root;
			while (p != null) {
				int c = k.compareTo(p.data);
				if (c < 0) {
					if (p.left == null) {
						p.left = new Node(k);
						break;
					}
					p = p.left;
				} else {
					if(p.right == null) {
						p.right = new Node(k);
						break;
					}
					p = p.right;
				}
			}
		}
		n++;
	}

	public Key search(Key k) {
		return search(k, root);
	}
	
	public Key search(Key k, Node p) {
		if(p == null)
			return null;
		int c = k.compareTo(p.data);
		if(c == 0)
			return k;
		else
			if(c < 0)
				return search(k,p.left);
			else
				return search(k,p.right);
	}

	public int size() {
		return n;
	}

	public boolean isEmpty() {
		return n == 0;
	}

	public Iterator<Key> iterator() {
		List<Key> lk = new ArrayList<Key>();
		traverse(root, lk);
		return lk.iterator();
	}
	
	public void traverse(Node node,List<Key> lk) {
		if(node != null) {
			lk.add(node.data);
			traverse(node.left, lk);
			traverse(node.right, lk);
		}
	}

	// duyệt cây theo thứ tự trước (tiền thứ tự)
	public void preTraverse() {
		preTraverse(root);
	}
	
	public void preTraverse(Node node) {
		if(node != null) {
			System.out.println(node.data);
			preTraverse(node.left);
			preTraverse(node.right);
		}
	}

	// duyệt cây theo thứ tự sau (hậu thứ tự)
	public void postTraverse() {
		postTraverse(root);
	}
	
	public void postTraverse(Node node) {
		if(node != null) {
			postTraverse(node.left);
			postTraverse(node.right);
			System.out.println(node.data);
		}
	}
	
	

	// duyệt cây theo thứ tự giữa (trung thứ tự)
	public void inTraverse() {
		inTraverse(root);
	}
	
	public void inTraverse(Node node) {
		if(node != null) {
			inTraverse(node.left);
			System.out.println(node.data);
			inTraverse(node.right);
		}
	}

	public static void main(String[] args) {
		SimpleBST<Integer> bst = new SimpleBST<>();

		int[] data = { 5, 6, 7, 1, 2, 3, 8, 6, 9, 0 };
		for (int i = 0; i < data.length; i++)
			bst.insert(data[i]);

		System.out.println("All element in tree:");
		System.out.println("All element in tree:");
		int[] t = new int[data.length];
		int id = 0;
		for (int d : bst) {
			t[id] = d;
			id++;
		}

		Arrays.sort(t);
		for (int d : t) {
			System.out.print(d + " ");
		}

		System.out.println("");
		System.out.println("Size of tree = " + bst.size());

		System.out.println("Search key = 4> " + bst.search(4));
		System.out.println("Search key = 6> " + bst.search(6));

		System.out.println("Pre-order tree traversal");
		bst.preTraverse();
		System.out.println("Post-order tree traversal");
		bst.postTraverse();
		System.out.println("In-order tree traversal");
		bst.inTraverse();

	}

}