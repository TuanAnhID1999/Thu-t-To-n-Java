import java.util.Stack;

public class Expression{
    
    public boolean isValidExpr(String expr)
    {
    	String pop = null;
    	StackInterface<String> str = new LinkedListStack<String>();
    	for (int i = 0; i < expr.length(); i++) {
    		if (expr.charAt(i)== '(') {
    			str.push("(");
				
			}else if(expr.charAt(i)== ')'){
				pop = str.pop();
			}
			
		}
    	if (str.isEmpty() && pop != null) {
			return true;
		}
    	
        return false;
    }
    
    public static void main(String[] args)
    {
        
        Expression expr = new Expression();
        String f = "a+b-c(3+a)";
        System.out.println(expr.isValidExpr(f));
        
    }
    
    
}