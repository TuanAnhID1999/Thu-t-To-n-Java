public class Manhattan{
    
    public static int manhattan(int[][] m)
    {
    	int row = 0;
    	int col = 0;
    	int manhattanSum = 0;
    	for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				if (m[i][j] != 0) {
					row = ( m[i][j] -1)/m.length;
					col = ( m[i][j] -1)%m.length;
					manhattanSum += Math.abs(row-i) + Math.abs(col -j);		
				}
					
			}
		}
        return manhattanSum;
    }
    
    public static void main(String[] args) {
		int [][] m = {{8,1,3},{4,0,2},{7,6,5}};
		System.out.println(manhattan(m));
	}
    
   
}