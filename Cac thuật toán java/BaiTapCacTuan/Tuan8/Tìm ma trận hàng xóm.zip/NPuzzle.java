import java.util.LinkedList;

public class NPuzzle {

	static LinkedList<int[][]> nes = new LinkedList<int[][]>();

	int[][] puzzle(int[][] m) {
		int[][] b = new int[m.length][m.length];
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				b[i][j] = m[i][j];
			}
		}
		return b;

	}

	public Iterable<int[][]> neighbors(int[][] m) {
		int x = 0;
		int y = 0;
		int size = m.length;
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				if (m[i][j] == 0) {
					x = i;
					y = j;

				}
			}
		}
		if (x != 0) {
			int[][] b1 = puzzle(m);
			int tmp = b1[x][y];
			b1[x][y] = b1[x - 1][y];
			b1[x - 1][y] = tmp;
			nes.add(b1);
		}
		if (x != size - 1) {
			int[][] b2 = puzzle(m);
			int tmp = b2[x][y];
			b2[x][y] = b2[x + 1][y];
			b2[x + 1][y] = tmp;
			nes.add(b2);
		}
		if (y != 0) {
			int[][] b3 = puzzle(m);
			int tmp = b3[x][y];
			b3[x][y] = b3[x][y - 1];
			b3[x][y - 1] = tmp;
			nes.add(b3);
		}
		if (y != size - 1) {
			int[][] b4 = puzzle(m);
			int tmp = b4[x][y];
			b4[x][y] = b4[x][y + 1];
			b4[x][y + 1] = tmp;
			nes.add(b4);
		}
		return nes;

	}
}