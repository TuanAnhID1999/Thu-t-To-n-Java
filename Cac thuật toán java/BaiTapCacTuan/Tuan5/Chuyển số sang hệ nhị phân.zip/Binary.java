@SuppressWarnings("unchecked")
public class Binary{
    
    public static String toBinary(int n)
    {
    	if(n == 0){
    		return String.valueOf(0);
    	}else {
			int b = Integer.valueOf(toBinary(n/2))*10+(n%2);
			return String.valueOf(b);
		}
		
    	
    }
    
    public static void main(String[] args)
    {
        int n =  6;
        
        System.out.println("So "+ n+" co dang nhi phan la: " + toBinary(n));
        
    }
}