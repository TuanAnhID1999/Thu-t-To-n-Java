public class TopK {
	/*
	 * Hoàn thiện phương thức getTopk trả lại giá trị lớn thứ k trong dãy k <=
	 * a.length
	 */
	public static int getTopk(int[] a, int k) {
		int number = 0;
		for (int i = 0; i < a.length ; i++) {
			for (int j = a.length -1; j >0; j--) {
				if (a[j-1] < a[j]) {
				
					int t = a[j-1];
					a[j-1]= a[j];
					a[j]= t;
				}
				if (k ==i+1) {
					number = a[i];
				}
			}
		}
		return number;
	}

	public static void main(String[] args) {
		int[] a = { 1, 3, 2, 1, 4, 5, 7, 9, 8, 5, 6 };
		int k = 1;

		System.out.printf("Phần tử lớn thứ %d là: %d", k, getTopk(a, k));

	}
}
